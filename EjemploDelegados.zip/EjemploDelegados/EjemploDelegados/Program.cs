﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjemploDelegados
{
    class Program
    {
        static void Main(string[] args)
        {
            var archivo = new Archivo() { Titulo = "Archivo 1" };
            var asistenteDescarga = new AsistenteDescarga();//emisor
            var servicioDesempacar = new ServicioDesempacar();//Receptor

            asistenteDescarga.ArchivoDescargado += servicioDesempacar.EnArchivoDescargado;
            asistenteDescarga.Descarga(archivo);
        }
    }

    public class ServicioDesempacar
    {
        public void EnArchivoDescargado(object fuente, EventArgs e)
        {
            Console.WriteLine("ServicioDesempacar: desempacando el archivo...");
        }
    }
}
